<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Affecter temps</title>
</head>
<body>

    @if($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
    <h3>Les participants</h3>

    <form action="/affecter_temps_participe" method="post">
        @csrf

        <h3>Temps de départ</h3>
        <input type="text" name="temps_depart" placeholder="hh:mm:ss" required>

        <table border="1">
            <caption>Liste de mes coureurs participants</caption>
            <tr>
                <th>Id</th>
                <th>Nom</th>
                <th>Numéro de dossard</th>
                <th>Genre</th>
                <th>Équipe</th>
                <th>Catégorie</th>
                <th>Titre de l'étape</th>
                <th>Temps d'arrivée</th>
                <th>Temps de pénalisation</th>
            </tr>
            @foreach ($coureur_participe as $c)
            <tr>
                <td>{{ $c->id_coureur_etape }}</td>
                <td>{{ $c->coureur_nom }}</td>
                <td>{{ $c->numero_dossard }}</td>
                <td>{{ $c->genre }}</td>
                <td>{{ $c->equipe_nom }}</td>
                <td>{{ $c->categorie_nom }}</td>
                <td>{{ $c->etape_nom }}</td>
                <td>
                    <input type="text" name="temps_arrive[{{ $c->id_coureur_etape }}]" placeholder="hh:mm:ss" required>
                </td>
                <td>
                    <input type="text" name="temps_penalise[{{ $c->id_coureur_etape }}]" placeholder="hh:mm:ss" required>
                </td>
            </tr>
            @endforeach
        </table>

        <button type="submit">Affecter le temps</button>
    </form>

    @if(session('success'))
    <div style="color: green;">
        {{ session('success') }}
    </div>
    @endif

</body>
</html>
