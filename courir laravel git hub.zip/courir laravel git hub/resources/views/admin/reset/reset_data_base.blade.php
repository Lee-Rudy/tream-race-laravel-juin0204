<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>reset database</title>
</head>
<body>

    <form action="/reset_database" method="post">
        @csrf
        <label for="reset"> initialisé toute la base de donnée</label>
        <button type="submit">initialiser</button>
    
    </form>

    @if(session('reset-database'))
<div style="color: green;">
    <p>succes supprsiion </p>
    {{ session('reset-database') }}
</div>
@endif
    

    @if(session('flash_message'))
    <div class="alert alert-success" style="background-color: #d4edda; border-color: #c3e6cb; color: #ffffff;">
        {{ session('flash_message') }}
    </div>
@endif

@if($errors->any())
    <div class="alert alert-danger" style="background-color: #c41374; border-color: #c41374; color: #ffffff;>
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
    
</body>
</html>