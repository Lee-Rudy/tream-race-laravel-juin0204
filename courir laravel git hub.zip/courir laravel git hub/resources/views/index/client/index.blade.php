<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>

    <form action="/login" method="post">
        @csrf
        <label for="login">
            <span>Login</span>
            <input type="text" name="login" id="pwd">

            <span>mot de passe</span>
            <input type="text" name="pwd" id="pwd">

            <input type="submit" value="se connecter">
        </label>
    </form>
    
</body>
</html>