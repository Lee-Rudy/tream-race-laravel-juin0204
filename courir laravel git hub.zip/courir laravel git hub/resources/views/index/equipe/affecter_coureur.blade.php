<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Affectations des coureurs</title>
</head>
<body>
    <form action="/affecter" method="post">
        @csrf

        <h3>Choisir une étape</h3>
        <select name="etape" id="etape">
            @foreach ($etapes as $etape)
                <option value="{{ $etape->id_etapes }}">
                    {{ $etape->nom }} ({{ $etape->nbre_coureur_equipe }})
                </option>
            @endforeach
        </select>

        <h3>Mes Coureurs</h3>
        
        <table border="1">
            <caption>Liste de mes coureurs</caption>
            <tr>
                <th>Id</th>
                <th>Nom</th>
                <th>Numéro de dossard</th>
                <th>Genre</th>
                <th>Équipe</th>
                <th>Catégorie</th>
                <th>faire le choix</th>

            </tr>
            @foreach ($coureurs as $c)
            <tr>
                <td>{{$c->id_equipe_coureur}}</td>
                <td>{{ $c->coureur_nom }}</td>
                <td>{{ $c->numero_dossard }}</td>
                <td>{{ $c->genre }}</td>
                <td>{{ $c->equipe_nom }}</td>
                <td>{{ $c->categorie_nom }}</td>
                <td><input type="checkbox" name="id_equipe_coureur[]" value="{{ $c->id_equipe_coureur }}"></td>
            </tr>
            @endforeach
        </table>
        
        <button type="submit">Affecter</button>
    </form>

    @if(session('error'))
    <div style="color: rgb(162, 9, 17);">
        <p>succes supprsiion </p>
        {{ session('error') }}
    </div>
    @endif
</body>
</html>
