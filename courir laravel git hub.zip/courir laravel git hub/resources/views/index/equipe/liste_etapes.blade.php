<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>{{session('login')}}</h1>
    <table border="1">
        <caption>Listes des Etapes</caption>
        <tr>
            <th>Titre</th>
            <th>Longeur</th>
            <th>nombre d'équipe oblligatoire</th>
            <th>numéro de l'étape</th>
        </tr>
        @foreach ( $etapes as $etape ) 
        <tr>
            <td>{{$etape->nom}}</td>
            <td>{{$etape->longeur}} KM</td>
            <td>{{$etape->nbre_coureur_equipe}}</td>
            <td>{{$etape->rang_etape}}</td>
        </tr>
        @endforeach
    </table>

    <a href="/affecter_coureur">affecter des coureurs</a>
</body>
</html>