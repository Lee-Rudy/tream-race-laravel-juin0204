--postgres/laravel
--database name : néant

CREATE TABLE Admin (
    id SERIAL PRIMARY KEY,
    login VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Equipe (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    login VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Coureur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    numero_dossard INTEGER UNIQUE NOT NULL,
    genre VARCHAR(20) NOT NULL,
    date_naissance DATE NOT NULL
);

CREATE TABLE Categorie (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(50) NOT NULL
);



CREATE TABLE CategorieCoureur (
    id SERIAL PRIMARY KEY,
    coureur_id INTEGER NOT NULL REFERENCES Coureur(id),
    categorie_id INTEGER NOT NULL REFERENCES Categorie(id)
);

CREATE TABLE Etape (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    longueur_km DECIMAL(5,2) NOT NULL,
    nb_coureur_par_equipe INTEGER NOT NULL,
    rang_etape INTEGER NOT NULL
);

CREATE TABLE CoureurEtape (
    id SERIAL PRIMARY KEY,
    etape_id INTEGER NOT NULL REFERENCES Etape(id),
    equipe_id INTEGER NOT NULL REFERENCES Equipe(id),
    coureur_id INTEGER NOT NULL REFERENCES Coureur(id),
    heure_depart TIME NOT NULL,
    heure_arrivee TIME NOT NULL,
    penalite TIME,
    points INTEGER
);

CREATE TABLE Classement (
    id SERIAL PRIMARY KEY,
    etape_id INTEGER NOT NULL REFERENCES Etape(id),
    equipe_id INTEGER NOT NULL REFERENCES Equipe(id),
    rang INTEGER NOT NULL,
    points INTEGER NOT NULL
);
