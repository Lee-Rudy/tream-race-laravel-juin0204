--postgres/laravel
--databasename : run
--peut être tout initialisé les insertions sauf login admin

create table admin_user
(
    id_admin_user serial primary key,
    login varchar(255),
    pwd varchar(255)
);

insert into admin_user (login,pwd) values('admin', 'admin');

--les tables par défauts à ne pas toucher CRUD
--======================================================================

create table etapes
(
    id_etapes serial primary key,
    nom varchar(100),
    longeur varchar(255), --en km
    nbre_coureur_equipe int,
    rang_etape VARCHAR(255)
);
insert into etapes (nom,longeur,nbre_coureur_equipe,rang_etape)values('ankadifotsy','2', 3, '1'),
('akorondrano','3.5', 3, '2'),
('analakely','1', 2, '3');

create table coureur
(
    id_coureur serial primary key,
    nom varchar(300),
    numero_dossard varchar(255),
    genre varchar(100), --Homme ou Femme
    dtn date
);
INSERT INTO coureur (nom, numero_dossard, genre, dtn) VALUES
('Alice Martin', 'A123', 'Femme', '2000-05-14'),
('Bob Dupont', 'B456', 'Homme', '1998-08-21'),
('Caroline Durand', 'C789', 'Femme', '2002-11-03'),
('David Moreau', 'D012', 'Homme', '1995-07-30'),
('Eva Bernard', 'E345', 'Femme', '1999-03-22'),
('Frank Petit', 'F678', 'Homme', '2001-02-14'),
('Gina Dubois', 'G901', 'Femme', '2003-12-19'),
('Hugo Lambert', 'H234', 'Homme', '1997-09-08'),
('Isabelle Leroy', 'I567', 'Femme', '2000-04-25');


create table categorie
(
    id_categorie serial primary key,
    nom varchar(255)  --junior, senior
);
insert into categorie(nom) values ('junior'),('senior');

create table equipe
(
    id_equipe serial primary key,
    nom varchar(255),
    login varchar(255), --nom de l'equipe
    pwd varchar(255)
    --se connecte avec le login et le mot de passe 
);

INSERT INTO equipe (nom, login, pwd) VALUES
('Les Sprinters', 'les_sprinters', 'password1'),
('Marathon Masters', 'marathon_masters', 'password2'),
('Trail Blazers', 'trail_blazers', 'password3');


--======================================================================

--table de jonction : categorie et coureur
create table categorie_coureur
(
    id_categorie_coureur serial primary key,
    id_coureur int REFERENCES coureur(id_coureur),
    id_categorie int REFERENCES categorie(id_categorie)
);
INSERT INTO categorie_coureur (id_coureur, id_categorie) VALUES
(1, 2), -- Alice Martin, Senior
(2, 2), -- Bob Dupont, Senior
(3, 1), -- Caroline Durand, Junior
(4, 2), -- David Moreau, Senior
(5, 2), -- Eva Bernard, Senior
(6, 1), -- Frank Petit, Junior
(7, 1), -- Gina Dubois, Junior
(8, 2), -- Hugo Lambert, Senior
(9, 2); -- Isabelle Leroy, Senior


create table equipe_coureur
(
    id_equipe_coureur serial primary key,
    id_categorie_coureur int REFERENCES categorie_coureur(id_categorie_coureur),
    id_equipe int REFERENCES equipe(id_equipe)
);

INSERT INTO equipe_coureur (id_categorie_coureur, id_equipe) VALUES
(1, 1), -- Alice Martin, Les Sprinters
(2, 1), -- Bob Dupont, Les Sprinters
(3, 2), -- Caroline Durand, Marathon Masters
(4, 2), -- David Moreau, Marathon Masters
(5, 3), -- Eva Bernard, Trail Blazers
(6, 3), -- Frank Petit, Trail Blazers
(7, 1), -- Gina Dubois, Les Sprinters
(8, 2), -- Hugo Lambert, Marathon Masters
(9, 3); -- Isabelle Leroy, Trail Blazers

--detail des coureurs pour chaque équipe
create view view_coureur_equipe as
SELECT 
    ec.id_equipe_coureur,
    c.nom AS coureur_nom,
    c.numero_dossard as numero_dossard,
    c.genre as genre,
    cat.nom AS categorie_nom,
    c.dtn as dtn,
    e.login AS equipe_nom
FROM 
    equipe_coureur ec
LEFT JOIN 
    categorie_coureur cc ON ec.id_categorie_coureur = cc.id_categorie_coureur
LEFT JOIN 
    coureur c ON cc.id_coureur = c.id_coureur
LEFT JOIN 
    equipe e ON ec.id_equipe = e.id_equipe
LEFT JOIN 
    categorie cat ON cc.id_categorie = cat.id_categorie;

-- id_categorie_coureur int REFERENCES categorie_coureur(id_categorie_coureur),

-- INSERT INTO equipe_coureur_equipe (id_coureur, id_equipe)
-- SELECT 1, id_equipe
-- FROM equipe
-- WHERE id_coureur IN (1, 2, 3, 4, 5);

--======================================================================================================================
--table utilisé pour affecté le coureur
create table coureur_etape
(
    id_coureur_etape serial primary key,
    id_equipe_coureur int REFERENCES equipe_coureur(id_equipe_coureur),
    id_etapes int REFERENCES etapes(id_etapes)
);

--table utilisé pour affecter le temps d'arriver des coureurs pour chaque étape
create table temps_coureur
(
    id_temps_coureur serial primary key,
    id_coureur_etape int REFERENCES coureur_etape(id_coureur_etape),
    temps_depart text,
    temps_arrivee text,
    temps_penalise text,
    temps_totals text
);

-- ALTER TABLE temps_coureur
--     ALTER COLUMN temps_depart TYPE text USING temps_depart::text,
--     ALTER COLUMN temps_arrivee TYPE text USING temps_arrivee::text,
--     ALTER COLUMN temps_penalise TYPE text USING temps_penalise::text,
--     ALTER COLUMN temps_totals TYPE text USING temps_totals::text;

--======================================================================================================================

--view pour voir les coureurs qui participent
create view view_coureur_participe AS
SELECT 
    ce.id_coureur_etape,
    c.nom AS coureur_nom,
    c.numero_dossard as numero_dossard,
    c.genre as genre,
    e.login as equipe_nom,
    cat.nom AS categorie_nom,
    et.nom AS etape_nom
FROM 
    coureur_etape ce
LEFT JOIN 
    equipe_coureur ec ON ce.id_equipe_coureur = ec.id_equipe_coureur
LEFT JOIN 
    categorie_coureur cc ON ec.id_categorie_coureur = cc.id_categorie_coureur
LEFT JOIN 
    coureur c ON cc.id_coureur = c.id_coureur
LEFT JOIN 
    equipe e ON ec.id_equipe = e.id_equipe
LEFT JOIN 
    categorie cat ON cc.id_categorie = cat.id_categorie
LEFT JOIN 
    etapes et ON ce.id_etapes = et.id_etapes;

-------------------------------------------------------
CREATE TABLE donner_points 
(
    id_donner_points serial primary key,
    classement INTEGER,
    points INTEGER
);

INSERT INTO donner_points (classement, points) VALUES
(1, 10),
(2, 6),
(3, 4),
(4, 2),
(5, 1);
--------------------------------------------------------
























-----------------------------------------
create table test_heure_text
(
    id serial primary key,
    heure text
);

insert into test_heure_text(heure) values('25:25:25');
insert into test_heure_text(heure) values('1:1:1');
insert into test_heure_text(heure) values('1:1:1');


--convertir le texte en intervalle 
select
    heure,
    (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[1]::int * interval '1 hour' +
    (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[2]::int * interval '1 minute' +
    (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[3]::int * interval '1 second' as interval_heure
from
    test_heure_text;


--faire la somme des intervalles
    with heures_intervals as (
    select
        (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[1]::int * interval '1 hour' +
        (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[2]::int * interval '1 minute' +
        (regexp_matches(heure, '(\d+):(\d+):(\d+)'))[3]::int * interval '1 second' as interval_heure
    from
        test_heure_text
)
select sum(interval_heure) as total_interval
from heures_intervals;
-------------------------------------------


