create table admin_user
(
    id_admin_user serial primary key,
    login varchar(255),
    pwd varchar(255)
);

create table etapes
(
    id_etapes serial primary key,
    nom varchar(100),
    longeur varchar(255), --en km
    nbre_coureur_equipe int,
    rang_etape VARCHAR(255)
);

create table coureur
(
    id_coureur serial primary key,
    nom varchar(300),
    numero_dossard varchar(255),
    genre varchar(100), --Homme ou Femme
    dtn date
);

create table categorie
(
    id_categorie serial primary key,
    nom varchar(255)  --junior, senior
);

create table equipe
(
    id_equipe serial primary key,
    nom varchar(255),
    login varchar(255), --nom de l'equipe
    pwd varchar(255)
    --se connecte avec le login et le mot de passe 
);

create table categorie_coureur
(
    id_categorie_coureur serial primary key,
    id_coureur int REFERENCES coureur(id_coureur),
    id_categorie int REFERENCES categorie(id_categorie)
);

create table equipe_coureur
(
    id_equipe_coureur serial primary key,
    id_categorie_coureur int REFERENCES categorie_coureur(id_categorie_coureur),
    id_equipe int REFERENCES equipe(id_equipe)
);

create table coureur_etape
(
    id_coureur_etape serial primary key,
    id_equipe_coureur int REFERENCES equipe_coureur(id_equipe_coureur),
    id_etapes int REFERENCES etapes(id_etapes)
);


create table temps_coureur
(
    id_temps_coureur serial primary key,
    id_coureur_etape int REFERENCES coureur_etape(id_coureur_etape),
    temps_depart text,
    temps_arrivee text,
    temps_penalise text,
    temps_totals text
);
