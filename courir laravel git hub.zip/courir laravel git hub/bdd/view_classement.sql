CREATE VIEW view_classement_etape AS
SELECT 
    ce.id_equipe_coureur,
    e.nom AS equipe,
    c.nom AS coureur,
    et.nom AS etape,
    et.longeur AS distance,
    tc.temps_depart,
    tc.temps_arrivee,
    tc.temps_penalise,
    tc.temps_totals,
    ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) AS classement,
    CASE
        WHEN ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) = 1 THEN 10
        WHEN ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) = 2 THEN 6
        WHEN ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) = 3 THEN 4
        WHEN ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) = 4 THEN 2
        WHEN ROW_NUMBER() OVER (PARTITION BY ce.id_etapes ORDER BY tc.temps_totals) = 5 THEN 1
        ELSE 0
    END AS points
FROM 
    temps_coureur tc
JOIN 
    coureur_etape ce ON tc.id_coureur_etape = ce.id_coureur_etape
JOIN 
    equipe_coureur ec ON ce.id_equipe_coureur = ec.id_equipe_coureur
JOIN 
    equipe e ON ec.id_equipe = e.id_equipe
JOIN 
    categorie_coureur cc ON ec.id_categorie_coureur = cc.id_categorie_coureur
JOIN 
    coureur c ON cc.id_coureur = c.id_coureur
JOIN 
    etapes et ON ce.id_etapes = et.id_etapes
ORDER BY 
    ce.id_etapes, classement;






    -----------------------------------------------------------------------

CREATE VIEW view_classement_generale_equipe AS
SELECT
    equipe.nom AS equipe,
    SUM(CASE
            WHEN classement = 1 THEN 10
            WHEN classement = 2 THEN 6
            WHEN classement = 3 THEN 4
            WHEN classement = 4 THEN 2
            WHEN classement = 5 THEN 1
            ELSE 0
        END) AS total_points
FROM
    view_classement_etape
JOIN
    equipe_coureur ON view_classement_etape.id_equipe_coureur = equipe_coureur.id_equipe_coureur
JOIN
    equipe ON equipe_coureur.id_equipe = equipe.id_equipe
GROUP BY
    equipe.nom
ORDER BY
    total_points DESC
LIMIT 5;




--------------------------------------------------------------------

