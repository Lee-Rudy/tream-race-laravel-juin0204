<?php

namespace App\Models\view;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class view_coureur_equipe extends Model
{
    //view pour voir les coureurs dans l"equipe et qui va être affécté
    public $timestamps = false;

    protected $table = 'view_coureur_equipe';

    protected $primaryKey = 'id_equipe_coureur';

    protected $fillable = ['coureur_nom','numero_dossard','genre','categorie_nom','dtn','equipe_nom'];
}
