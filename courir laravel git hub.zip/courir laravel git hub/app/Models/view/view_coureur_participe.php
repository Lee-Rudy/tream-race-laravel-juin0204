<?php

namespace App\Models\view;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class view_coureur_participe extends Model
{
    //view pour voir les coureurs qui participents
    public $timestamps = false;

    protected $table = 'view_coureur_participe';

    protected $primaryKey = 'id_coureur_etape';

    protected $fillable = ['coureur_nom','numero_dossard','genre','equipe_nom','categorie_nom','etape_nom'];
}
