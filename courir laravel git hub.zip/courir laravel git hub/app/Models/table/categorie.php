<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class categorie extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'categorie';

    protected $primaryKey = 'id_categorie';

    protected $fillable = ['nom'];
}
