<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class categorie_coureur extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'categorie_coureur';

    protected $primaryKey = 'id_categorie_coureur';

    protected $fillable = ['id_coureur','id_categorie'];
}
