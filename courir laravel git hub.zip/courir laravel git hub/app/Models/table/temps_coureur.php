<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class temps_coureur extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'temps_coureur';

    protected $primaryKey = 'id_temps_coureur';

    protected $fillable = ['id_coureur_etape','temps_depart','temps_arrivee','temps_penalise','temps_totals'];
}
