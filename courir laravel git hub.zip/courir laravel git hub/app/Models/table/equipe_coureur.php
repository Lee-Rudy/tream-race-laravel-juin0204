<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class equipe_coureur extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'equipe_coureur';

    protected $primaryKey = 'id_equipe_coureur';

    protected $fillable = ['id_coureur','id_equipe'];
}
