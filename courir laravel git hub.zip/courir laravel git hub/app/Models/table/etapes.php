<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class etapes extends Model
{
    // use HasFactory;:

    public $timestamps = false;

    protected $table = 'etapes';

    protected $primaryKey = 'id_etapes';

    protected $fillable = ['nom','longeur','nbre_coureur_equipe','rang_etape'];
}
