<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class equipe extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'equipe';

    protected $primaryKey = 'id_equipe';

    protected $fillable = ['nom','login','pwd'];
}
