<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class donner_points extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'donner_points';

    protected $primaryKey = 'id_donner_points';

    protected $fillable = ['classement','points'];
}
