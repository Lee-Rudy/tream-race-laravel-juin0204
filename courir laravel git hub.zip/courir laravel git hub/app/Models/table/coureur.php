<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class coureur extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'coureur';

    protected $primaryKey = 'id_coureur';

    protected $fillable = ['nom','numero_dossard','genre','dtn'];
}
