<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class coureur_etape extends Model
{
    // use HasFactory;
    public $timestamps = false;

    protected $table = 'coureur_etape';

    protected $primaryKey = 'id_coureur_etape';

    protected $fillable = ['id_equipe_coureur','id_etapes'];
}
