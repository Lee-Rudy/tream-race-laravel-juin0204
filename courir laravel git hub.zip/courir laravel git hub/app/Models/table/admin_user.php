<?php

namespace App\Models\table;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class admin_user extends Model
{
    // use HasFactory;

    public $timestamps = false;

    protected $table = 'admin_user';

    protected $primaryKey = 'id_admin_user';

    protected $fillable = ['login','pwd'];
}
