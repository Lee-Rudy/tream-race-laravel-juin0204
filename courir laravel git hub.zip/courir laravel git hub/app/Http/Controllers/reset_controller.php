<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\table\temps_coureur;
use App\Models\table\coureur_etape;
use App\Models\table\equipe_coureur;
use App\Models\table\categorie_coureur;
use App\Models\table\equipe;
use App\Models\table\coureur;
use App\Models\table\etapes;

class reset_controller extends Controller
{
    //

    public function reset()
    {
        temps_coureur::truncate();
        coureur_etape::truncate();
        equipe_coureur::truncate();
        categorie_coureur::truncate();
        equipe::truncate();
        coureur::truncate();
        etapes::truncate();

        
        return redirect()->back()->with('reset-database', 'Les données de la base de données ont été réinitialisées avec succès.');
    }
}
