<?php

namespace App\Http\Controllers\admin\affecter_temps;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Models\view\view_coureur_participe;
use App\Models\table\temps_coureur;
use App\Models\table\coureur_etape;

class affecter_temps_controller extends Controller
{
    // Afficher les participants
    public function index()
    {
        $coureur_participe = view_coureur_participe::all();
        return view('admin.affecter_temps.affecter_temps', ['coureur_participe' => $coureur_participe]);
    }

    // Affecter les temps
    public function affecter_temps(Request $request)
    {

        $request->validate([
            'temps_depart' => 'required|regex:/^\d{1,2}:\d{2}:\d{2}$/',
            'temps_arrive.*' => 'required|regex:/^\d{1,2}:\d{2}:\d{2}$/',
            'temps_penalise.*' => 'required|regex:/^\d{1,2}:\d{2}:\d{2}$/',
        ], [
            'temps_depart.required' => 'Le temps de départ est requis.',
            'temps_depart.regex' => 'Le temps de départ doit être au format hh:mm:ss.',
            'temps_arrive.*.required' => 'Le temps d\'arrivée est requis pour chaque coureur.',
            'temps_arrive.*.regex' => 'Le temps d\'arrivée doit être au format hh:mm:ss.',
            'temps_penalise.*.required' => 'Le temps de pénalisation est requis pour chaque coureur.',
            'temps_penalise.*.regex' => 'Le temps de pénalisation doit être au format hh:mm:ss.',
        ]);


        $temps_depart = $request->input('temps_depart');
        $temps_arrive = $request->input('temps_arrive');
        $temps_penalise = $request->input('temps_penalise');

        foreach ($temps_arrive as $id_coureur_etape => $arrive) {
            $penalise = $temps_penalise[$id_coureur_etape] ?? '00:00:00';

            $temps_total = $this->somme_temps($arrive, $penalise);

            $temps_coureur = temps_coureur::where('id_coureur_etape', $id_coureur_etape)->first();
            if ($temps_coureur) {
                $temps_coureur->temps_arrivee = $arrive;
                $temps_coureur->temps_penalise = $penalise;
                $temps_coureur->temps_totals = $temps_total;
            } else {
                $temps_coureur = new temps_coureur();
                $temps_coureur->id_coureur_etape = $id_coureur_etape;
                $temps_coureur->temps_depart = $temps_depart;
                $temps_coureur->temps_arrivee = $arrive;
                $temps_coureur->temps_penalise = $penalise;
                $temps_coureur->temps_totals = $temps_total;
            }
            $temps_coureur->save();
        }

        return redirect()->back()->with('success', 'Les temps ont été affectés avec succès.');
    }

    // Convertir le temps au format hh:mm:ss en secondes
    private function convertToSeconds($time)
    {
        list($hours, $minutes, $seconds) = explode(':', $time);
        return $hours * 3600 + $minutes * 60 + $seconds;
    }

    // Convertir les secondes en format hh:mm:ss
    private function convertToTimeFormat($total_seconds)
    {
        $hours = floor($total_seconds / 3600);
        $minutes = floor(($total_seconds % 3600) / 60);
        $seconds = $total_seconds % 60;

        // Utiliser sprintf pour formater les valeurs correctement
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    // Calculer la somme des temps
    private function somme_temps($time1, $time2)
    {
        $seconds1 = $this->convertToSeconds($time1);
        $seconds2 = $this->convertToSeconds($time2);
        $total_seconds = $seconds1 + $seconds2;

        return $this->convertToTimeFormat($total_seconds);
    }
}
