<?php

namespace App\Http\Controllers\client\equipe;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;


use App\Models\view\view_coureur_equipe;
use App\Models\table\etapes;
use App\Models\table\coureur_etape;


class coureur_affecte_controller extends Controller
{
    //afficher les choix et les selectionnées 
    public function index(Request $request)
    {
        $nom_equipe = $request->session()->get('login');
        $coureurs = view_coureur_equipe::where('equipe_nom', $nom_equipe)->get();
        $etapes = etapes::all();

        return view('index.equipe.affecter_coureur', ['coureurs' => $coureurs, 'etapes' => $etapes]);
    }


   // Insertion des coureurs dans la table coureur_etape
   public function affecter_coureur(Request $request)
   {
       $id_etape = $request->input('etape');
       $id_equipe_coureur = $request->input('id_equipe_coureur');

       // Vérification du nombre de cases cochées
       $etape = etapes::find($id_etape);
       $nbre_coureur_equipe = $etape->nbre_coureur_equipe;

       if (count($id_equipe_coureur) !== $nbre_coureur_equipe) {
           return redirect()->back()->with('error', 'Le nombre de coureurs sélectionnés ne correspond pas au nombre requis pour cette étape.');
       }

       // Insertion des coureurs sélectionnés dans la table coureur_etape
       foreach ($id_equipe_coureur as $id) {
           $coureur = new coureur_etape();
           $coureur->id_equipe_coureur = $id;
           $coureur->id_etapes = $id_etape;
           $coureur->save();
       }

       return redirect('/liste_etapes')->with('success', 'Les coureurs ont été affectés avec succès.');
   }

    //fonction pour vérifier si les choix suivent le nombre de coureur par équipe 

}
