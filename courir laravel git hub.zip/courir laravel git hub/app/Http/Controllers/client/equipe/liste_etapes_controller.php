<?php

namespace App\Http\Controllers\client\equipe;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\table\etapes;

class liste_etapes_controller extends Controller
{
    //listes de tout les étapes du parcours 
    public function index()
    {

        $etapes = etapes::all();

        return view('index/equipe/liste_etapes', ['etapes'=>$etapes]);
    }
}
