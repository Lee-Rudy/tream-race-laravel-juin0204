<?php

namespace App\Http\Controllers\client\client_login;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\table\equipe;

class login_controller extends Controller
{
    // Connexion du client équipe
    public function connect_equipe(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'login' => 'required',
            'pwd' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 400);
        }

        $login = $request->input('login');
        $pwd = $request->input('pwd');

        $equipe = equipe::where('login', $login)
                        ->where('pwd', $pwd)
                        ->first();

        if (!$equipe) {
            return redirect('/')->with('errors', 'Erreur de connexion');
        } else {
            session(['id_equipe' => $equipe->id_equipe]);
            session(['login' => $equipe->login]);

            return redirect('/liste_etapes')->with('success', 'login succes');

        }
    }
}
