<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\client\client_login\login_controller;
use App\Http\Controllers\client\equipe\liste_etapes_controller;
use App\Http\Controllers\client\equipe\coureur_affecte_controller;
use App\Http\Controllers\reset_controller;
use App\Http\Controllers\admin\affecter_temps\affecter_temps_controller;



Route::get('/reset', function () {
    return view('admin/reset/reset_data_base');
});

Route::get('/', function () {
    return view('index/client/index');
});

Route::get('/liste_etapes', function () {
    return view('index/equipe/liste_etapes');
});

Route::get('/affecter_coureur', function () {
    return view('index/equipe/affecter_coureur');
});


Route::get('/affecter_temps', function () {
    return view('admin/affecter_temps/affecter_temps');
});

//------------------------------------------------------------------------
Route::post('/login', [login_controller::class, 'connect_equipe']);

Route::get('/liste_etapes', [liste_etapes_controller::class, 'index']);

Route::post('/reset_database', [reset_controller::class, 'reset']);

//affecter des coureurs à participae
Route::get('/affecter_coureur', [coureur_affecte_controller::class, 'index']);
Route::post('/affecter', [coureur_affecte_controller::class, 'affecter_coureur']);


//affecter les temps au coureurs
Route::get('/affecter_temps', [affecter_temps_controller::class, 'index']);
Route::post('/affecter_temps_participe', [affecter_temps_controller::class, 'affecter_temps']);


